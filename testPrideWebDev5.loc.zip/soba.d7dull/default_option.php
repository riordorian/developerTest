<?php
defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$nota_references_default_option = array(
    "max_image_size" => "500",
);
