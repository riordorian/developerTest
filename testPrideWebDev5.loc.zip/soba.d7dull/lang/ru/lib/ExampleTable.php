<?php
defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$MESS['ID'] = 'ID';
$MESS['NAME'] = 'Название';
$MESS['NAME_DEFAULT_VALUE'] = 'Безымянный элемент';
$MESS['IMAGE_SET'] = 'Изображения';
