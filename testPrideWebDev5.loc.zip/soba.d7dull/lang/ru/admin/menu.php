<?php
defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$MESS['REFERENCES_MENU_TEXT'] = 'Справочники';
$MESS['REFERENCES_MENU_TITLE'] = 'Справочники';
$MESS['REFERENCES_MENU_COUNTRY'] = 'Страны';
$MESS['REFERENCES_MENU_COUNTRYADDITIONAL'] = 'Страны, для покупки билетов в которые необходимо предоставить дополнительные сведения о пассажирах';
$MESS['REFERENCES_MENU_CITY'] = 'Города';
$MESS['REFERENCES_MENU_AIRPORT'] = 'Аэропорты';
$MESS['REFERENCES_MENU_ALLIANCE'] = 'Альянсы авиакомпаний';
$MESS['REFERENCES_MENU_AIRLINE'] = 'Авиакомпании';
$MESS['REFERENCES_MENU_AIRPLANE'] = 'Модели самолетов';
$MESS['REFERENCES_MENU_MEAL'] = 'Варианты питания';
$MESS['REFERENCES_MENU_DOCUMENT'] = 'Виды документов, удостоверяющие личность';
$MESS['REFERENCES_MENU_OFFER'] = 'Направления спецпредложений';
$MESS['REFERENCES_MENU_SUBOFFER'] = 'Поднаправления спецпредложений';
$MESS['REFERENCES_MENU_SERVICECLASS'] = 'Классы обслуживания';
$MESS['REFERENCES_MENU_AGEGROUP'] = 'Возрастные группы';
$MESS['REFERENCES_MENU_INITIATOR'] = 'Инициаторы отмены/обмена';
$MESS['REFERENCES_MENU_IMPORT'] = 'Импорт';
