<?php
defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$MESS['MODULE_NAME'] = 'D7 Образец';
$MESS['MODULE_DESCRIPTION'] = 'D7 Образец';
