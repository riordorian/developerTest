<?php
define('ADMIN_MODULE_NAME', 'soba.d7dull');

require_once $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php';

// @todo: Здесь - какой-то системный код, читающие данные и всё такое

require_once $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_after.php';

echo "Welcome to admin area";

require_once $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php';
